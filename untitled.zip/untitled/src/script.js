// NAVEGACIÓN ENTRE PANTALLAS

function mostrarPantalla(id){

    let pantallas = document.querySelectorAll(".pantalla");

    pantallas.forEach(p=>{
        p.classList.remove("activa");
    });

    document.getElementById(id).classList.add("activa");

    window.scrollTo({
        top:0,
        behavior:"smooth"
    });
}

// PANTALLA INICIAL

mostrarPantalla("inicio");
const preguntas = [

{
pregunta:"¿Cuál es el nombre científico del canguro rojo?",
opciones:["Chelonia mydas","Osphranter rufus","Birgus latro"],
correcta:1
},

{
pregunta:"¿Qué animal puede abrir cocos con sus pinzas?",
opciones:["Lori arcoíris","Tortuga verde","Cangrejo cocotero"],
correcta:2
},

{
pregunta:"¿Qué animal tiene colores azul, amarillo y blanco?",
opciones:["Babosa de mar","Canguro","Tortuga"],
correcta:0
},

{
pregunta:"¿Cuál es el nombre científico de la tortuga verde?",
opciones:["Chelonia mydas","Apteryx","Cocos nucifera"],
correcta:0
},

{
pregunta:"¿Qué planta produce cocos?",
opciones:["Pandanus","Taro","Cocos nucifera"],
correcta:2
},

{
pregunta:"¿Qué ave ayuda a transportar polen?",
opciones:["Lori arcoíris","Tortuga verde","Babosa de mar"],
correcta:0
},

{
pregunta:"¿Cuál es el nombre científico del árbol del pan?",
opciones:["Artocarpus altilis","Ipomoea batatas","Colocasia esculenta"],
correcta:0
},

{
pregunta:"¿Qué planta tiene una raíz rica en almidón?",
opciones:["Taro","Pandanus","Coco"],
correcta:0
},

{
pregunta:"¿Qué animal vive en mares tropicales?",
opciones:["Canguro","Tortuga verde","Lori"],
correcta:1
},

{
pregunta:"¿Qué árbol posee raíces especiales para mantenerse firme?",
opciones:["Pandanus","Camote","Taro"],
correcta:0
}

];

let preguntaActual = 0;

function cargarPregunta(){

let p = preguntas[preguntaActual];

document.getElementById("pregunta").innerHTML =
"Pregunta " + (preguntaActual+1) + "/10<br><br>" + p.pregunta;

let opciones = "";

p.opciones.forEach((opcion,index)=>{

opciones += `
<button class="opcion"
onclick="verificarRespuesta(${index})">
${opcion}
</button>
`;

});

document.getElementById("opciones").innerHTML = opciones;
document.getElementById("mensaje").innerHTML = "";

}

function verificarRespuesta(indice){

let correcta = preguntas[preguntaActual].correcta;

if(indice === correcta){

document.getElementById("mensaje").innerHTML =
"✅ ¡Correcto!";

setTimeout(()=>{

preguntaActual++;

if(preguntaActual >= preguntas.length){

mostrarPantalla("finalJuego");

}else{

cargarPregunta();

}

},1000);

}else{

document.getElementById("mensaje").innerHTML =
"❌ Incorrecto. Intenta nuevamente.";

}

}

function reiniciarJuego(){

preguntaActual = 0;

cargarPregunta();

mostrarPantalla("juego");

}
function mostrarPantalla(id){

let pantallas =
document.querySelectorAll(".pantalla");

pantallas.forEach(p=>{
p.classList.remove("activa");
});

document.getElementById(id)
.classList.add("activa");

if(id==="juego"){
cargarPregunta();
}

window.scrollTo({
top:0,
behavior:"smooth"
});

}